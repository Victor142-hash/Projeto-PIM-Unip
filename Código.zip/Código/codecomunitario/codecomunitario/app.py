
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/course')
def course():
    return render_template('course.html')

@app.route("/curso", methods=["GET", "POST"])
def curso():
    return render_template("course.html")

@app.route("/resposta", methods=["POST"])
def resposta():
    return render_template("course.html", request=request)

if __name__ == '__main__':
    app.run(debug=True)
